def total_price(unit_price, quantity=1, tax_rate=0.0):
    subtotal = unit_price * quantity
    return subtotal + tax_rate
